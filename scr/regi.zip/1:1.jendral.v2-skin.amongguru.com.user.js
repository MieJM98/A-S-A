// ==UserScript==
// @name         1:1.jendral.v2-skin.amongguru.com
// @namespace    http://tampermonkey.net/--https://skin.amongguru.com/
// @version      2023.12.15--18:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Liste des indices à rechercher
    const searchIndices = ["3R3ZpwJ", "dddddddd", "ddddddd", "vvvvvv", "vvvvv"];

    // Fonction pour récupérer deux réponses aléatoires depuis la source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    randomResponses.push(responses[randomIndex].trim());
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Rechercher les indices dans la balise spécifique
    const jobInstructionsDiv = document.querySelector('div#job-instructions');
    if (jobInstructionsDiv && searchIndices.some(indicator => jobInstructionsDiv.textContent.includes(indicator))) {
        // Appel de la fonction pour remplir les deux cases du formulaire

        getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/skin_.among_guru_.com.txt", 1, function(responsesProof1) {
            fillFormWithRandomResponses(responsesProof1, 'textarea#proof_1.form-control.alert-on-type-task');

            // Sélection de la source externe pour proof_2 en fonction de l'indice choisi
            const sources = [
                "https://pastebin.com/raw/1UBfN03Z",
                "https://pastebin.com/raw/9SbdJnYs",
                "https://pastebin.com/raw/tG5Uq3HV",
                "https://pastebin.com/raw/sCcL4fmc",
                "https://pastebin.com/raw/khC5ubQ3",
                "https://pastebin.com/raw/HSSGN2bp",
                "https://pastebin.com/raw/cvT4CAh9",
                "https://pastebin.com/raw/bMpidwrb",
                "https://pastebin.com/raw/0YsMUrcJ",
                "https://pastebin.com/raw/PJqLfHAH",
                "https://pastebin.com/raw/XRHhMWXa",
                "https://pastebin.com/raw/QsLRXt4f",
                "https://pastebin.com/raw/XpBTujRa",
                "https://pastebin.com/raw/VdR1JZaL"
            ];
            const selectedSourceIndex = Math.floor(Math.random() * sources.length);
            const selectedSource = sources[selectedSourceIndex];

            getRandomResponses(selectedSource, 1, function(responsesProof2) {
                fillFormWithRandomResponses(responsesProof2, 'textarea#proof_2.form-control.alert-on-type-task');

                // Use the same source for proof_3 if proof_2 is using an external source
                if (selectedSource.startsWith("https://pastebin.com/raw/")) {
                    getRandomResponses(selectedSource, 1, function(responsesProof3) {
                        fillFormWithRandomResponses(responsesProof3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                }
            });
        });
    }
})();