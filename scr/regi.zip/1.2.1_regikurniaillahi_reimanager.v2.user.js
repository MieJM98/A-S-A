// ==UserScript==
// @name         1.2.1_regikurniaillahi_reimanager.v2
// @namespace    http://tampermonkey.net/
// @version      2024.01.30
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


// ==UserScript==
// @name         1:1:2 regi_sui.iqipedia.com
// @namespace    http://tampermonkey.net/--https://sui.iqipedia.com/
// @version      2024.01.23--21:58
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 19H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text jampena.com+eng
    const foundIndex = document.body.textContent.includes("fugv805");//d5beec

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://pastebin.com/raw/QnviAVXS", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["IQI1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();




// ==UserScript==
// @name         1:1:2 regi_igun.uk/eng/
// @namespace    http://tampermonkey.net/--https://igun.uk/eng/
// @version      2024.01.23--20:20
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 20H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("6290f9");//

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/igun_.uk+eng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["IGN1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();








// ==UserScript==
// @name         1:1:2 regi_ryu.iqipedia.com
// @namespace    http://tampermonkey.net/--https://ryu.iqipedia.com/
// @version      2024.01.18--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2023, 19H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "" on the page
    const foundIndex = document.body.textContent.includes("ef6cbd");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses

                //https://ryu.iqipedia.com/what-is-dropshipping-business-a-beginner-s-guide/

                getRandomResponses("https://pastebin.com/raw/WMx6esnu", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["IQI1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();






// ==UserScript==
// @name         1:1:2 regi_uni.jakartastudio.com
// @namespace    http://tampermonkey.net/--https://uni.jakartastudio.com/
// @version      2024.01.09--16:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 19H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text jampena.com+eng
    const foundIndex = document.body.textContent.includes("4e60da");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses

                //https://uni.jakartastudio.com/harvard-university-a-prestigious-institution-shaping-the-minds-of-tomorrow/

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/uni_.jakarta_studio_.com.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["JAK1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();





// ==UserScript==
// @name         1:1:2 regi_www.reviewtekno.com/eng/
// @namespace    http://tampermonkey.net/--https://www.reviewtekno.com/eng/
// @version      2024.01.09--16:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 24, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text jampena.com+eng
    const foundIndex = document.body.textContent.includes("e251a0");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.review_tekno_.com+eng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["REV1"], 'textarea#vproof');  // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();







// ==UserScript==
// @name         1:1:2 regi_jagoweb.id/eng/
// @namespace    http://tampermonkey.net/--https://jagoweb.id/eng/
// @version      2024.01.18--16:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text jagoweb.id+eng
    const foundIndex = document.body.textContent.includes("c3021c");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/jago_web_.id%2Beng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["JAG1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();





// ==UserScript==
// @name         1:1:2 regi_jampena.com/eng/
// @namespace    http://tampermonkey.net/--https://jampena.com/eng/
// @version      2024.01.16--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("c28eb3");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/jam_pena_com%2Beng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["JAM1"], 'textarea#vproof');  // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();






// ==UserScript==
// @name         1:1:2 regi_maklumatkerja.com/eng/
// @namespace    http://tampermonkey.net/--https://maklumatkerja.com/eng/
// @version      2024.01.05--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("6y846o1");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/link.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["MAK1"], 'textarea#vproof');  // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();






// ==UserScript==
// @name         1:1:2 regi_www.ruangteknisi.com/eng/
// @namespace    http://tampermonkey.net/--https://www.ruangteknisi.com/eng/
// @version      2024.01.05--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("4bmchb5");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.ruang_teknisi_.com+eng/link.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["NIS1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();





// ==UserScript==
// @name         1:1:2 regi_otodrift.com/eng
// @namespace    http://tampermonkey.net/--https://otodrift.com/eng/
// @version      2024.01.19--02:16
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("c395b5");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses   https://otodrift.com/eng/the-gateway-to-university-excelling-in-admission-tests/
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/otodrift.com+eng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["OTO1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();





// ==UserScript==
// @name         1:1:2 regi_www.noos.co.id/study/
// @namespace    http://tampermonkey.net/--https://www.noos.co.id/study/
// @version      2024.01.23--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2023, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page
    const foundIndex = document.body.textContent.includes("f21412");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.noos_.co_.id-study.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["NOS1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();




// ==UserScript==
// @name         1:1:2 regi_kicaumania.net/eng/
// @namespace    http://tampermonkey.net/--https://kicaumania.net/eng/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page   https://kicaumania.net/eng/ecommerce-growth-hacking-strategies-for-rapid-expansion/

    const foundIndex = document.body.textContent.includes("ad431a");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/kicau_mania_.net+eng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["KIC1"], 'textarea#vproof'); // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();






// ==UserScript==
// @name         https://haru.dewagitar.com/
// @namespace    http://tampermonkey.net/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 23 JANVIER 2024, 22H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text jampena.com+eng
    const foundIndex = document.body.textContent.includes("0867ex0");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/haru_.dewa_gitar_.com.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["DEW1"], 'textarea#vproof');  // Change to "vitat"

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();