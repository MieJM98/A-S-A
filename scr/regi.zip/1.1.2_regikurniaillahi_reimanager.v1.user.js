// ==UserScript==
// @name         1.1.2_regikurniaillahi_reimanager.v1
// @namespace    http://tampermonkey.net/
// @version      2024.01.30
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==



/*


                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();

*/


// ==UserScript==
// @name         1:1:2 regi_aki.ahlinesia.com
// @namespace    http://tampermonkey.net/--https://aki.ahlinesia.com/
// @version      2023.10.31--03:58
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["gnjl7t7", "0c0afc", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/aki_.ahli_nesia_.com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})()




// ==UserScript==
// @name         1:1:2 regi_haru.apola.co(bce1bd)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["bce1bd", "000000000", "11111111", "22222222"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/haru_.apola_.co.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();






// ==UserScript==
// @name         1:1:2 regi_fuyu2.duniakicau.net
// @namespace    http://tampermonkey.net/-- https://fuyu2.duniakicau.net/
// @version      2023.11.15--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["36ei13u", "dc2f2a", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/fuy_u2_.dunia_kicau_.net.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();




// ==UserScript==
// @name         1:1:2 regi_studyus.carigaji.com
// @namespace    http://tampermonkey.net/--https://studyus.carigaji.com/
// @version      2023.11.14--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["5ccd57", "d049d1", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/studyus_.cari_gaji_.com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();



// ==UserScript==
// @name         1:1:2 regi_aki.combinesia.web.id
// @namespace    http://tampermonkey.net/--https://aki.combinesia.web.id/
// @version      2023.11.15--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["4e6a87", "ebdffb", "68f6f1"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/aki._combine_sia._web_.id.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_natsu.luvizhea.com
// @namespace    http://tampermonkey.net/--https://natsu.luvizhea.com/
// @version      2023.11.15--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["efc65e", "vyz902q", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/natsu_.luvi_zh_ea._com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_ecommerce.waktubaca.com
// @namespace    http://tampermonkey.net/--https://ecommerce.waktubaca.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["s03ytrb", "xxxxxxxxx", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/ecommerce_.waktu_baca._com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_uni.jakartastudio.com
// @namespace    http://tampermonkey.net/--https://uni.jakartastudio.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["_4e60da_", "dddddddd", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/uni_.jakarta_studio_.com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();






// ==UserScript==
// @name         1:1:2 regi_natsu2.apola.co
// @namespace    http://tampermonkey.net/--https://natsu2.apola.co/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Rechercher le texte "41bc94" sur la page
    const foundIndex = document.body.textContent.includes("41bc94");

    if (foundIndex) {
        // Remplir le premier champ (proof_1) avec 1 réponse aléatoire
        getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/nat_su2.ap_ola.co.txt", 1, function(response1) {
            fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

            // Remplir le deuxième champ (proof_2) avec 1 réponse aléatoire
            // "https://pastebin.com/raw/WZDb4YjN"  all prase
            getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                // Remplir le troisième champ (proof_3) avec 2 réponses aléatoires depuis différentes sources
                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                    fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                });
            });
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();




// ==UserScript==
// @name         1:1:2 regi_haru.ahlinesia.com
// @namespace    http://tampermonkey.net/--https://haru.ahlinesia.com
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["a03e66", "5e648c", "6e1ab2", "02lq2xk"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/haru_._ahli_nesia_._com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_haru.salamadian.com
// @namespace    http://tampermonkey.net/--http://haru.salamadian.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["7a0b17", "2oftnes", "mofogasy"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://pastebin.com/raw/5yDUj7Mg", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();




// ==UserScript==
// @name         1:1:2 regi_haru.putarmuter.com
// @namespace    http://tampermonkey.net/--https://haru.putarmuter.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["8ebfdc", "lprdvcm", "mofogasy"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/haru_.put_arm_uter._com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();



// ==UserScript==
// @name         1:1:2 regi_natsu2.duniakicau.net
// @namespace    http://tampermonkey.net/--https://natsu2.duniakicau.net/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["qb5rq16", "z1rm4sf", "mofogasy"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/nat_su2._dunia_kicau._net.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_au.carigaji.com
// @namespace    http://tampermonkey.net/--https://au.carigaji.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["3ee2a3", "c9f8a6", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://pastebin.com/raw/AizTU42W", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_kisetsu.luvizhea.com
// @namespace    http://tampermonkey.net/--https://kisetsu.luvizhea.com/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["28daf1", "dddddddd", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/kise_tsu._luvi_zhea_.com.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();






// ==UserScript==
// @name         1:1:2 regi_haru.combinesia.web.id
// @namespace    http://tampermonkey.net/--https://haru.combinesia.web.id/
// @version      2024.01.23--08:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["7iujbls", "b36bb1", "bbbbb", "bbbbbb"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/haru._combi_nesia._web_.id.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();



// ==UserScript==
// @name         1:1:2 regi_maklumatkerja.com/eng/
// @namespace    http://tampermonkey.net/--https://maklumatkerja.com/eng/
// @version      2024.01.05--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==



(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["6y846o1", "xxxxxxxxx", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/link.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/phrs.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_www.ruangteknisi.com/eng/
// @namespace    http://tampermonkey.net/--https://www.ruangteknisi.com/eng/
// @version      2024.01.05--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["4bmchb5", "xxxxxxxxx", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.ruang_teknisi_.com+eng/link.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.ruang_teknisi_.com+eng/phrs.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();






// ==UserScript==
// @name         1:1:2 regi_otodrift.com/eng
// @namespace    http://tampermonkey.net/--https://otodrift.com/eng/
// @version      2024.01.19--02:16
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==



(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["c395b5", "xxxxxxxxx", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/otodrift.com+eng.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/lia_.flash_tik_.com/phrase.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();





// ==UserScript==
// @name         1:1:2 regi_www.noos.co.id/study/
// @namespace    http://tampermonkey.net/--https://www.noos.co.id/study/
// @version      2024.01.05--19:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["f21412", "xxxxxxxxx", "sssssssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.noos_.co_.id-study.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();



// ==UserScript==
// @name         1:1:2 regi_kicaumania.net/eng/
// @namespace    http://tampermonkey.net/--https://kicaumania.net/eng/
// @version      2024.01.23--22:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["ad431a", "vvvvvvvvvvvvvvv", "mofogasy"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici  https://kicaumania.net/eng/ecommerce-growth-hacking-strategies-for-rapid-expansion/

            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/kicau_mania_.net+eng.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://pastebin.com/raw/1UBfN03Z",
                        "https://pastebin.com/raw/9SbdJnYs",
                        "https://pastebin.com/raw/tG5Uq3HV",
                        "https://pastebin.com/raw/sCcL4fmc",
                        "https://pastebin.com/raw/khC5ubQ3",
                        "https://pastebin.com/raw/HSSGN2bp",
                        "https://pastebin.com/raw/cvT4CAh9",
                        "https://pastebin.com/raw/bMpidwrb",
                        "https://pastebin.com/raw/0YsMUrcJ",
                        "https://pastebin.com/raw/PJqLfHAH",
                        "https://pastebin.com/raw/XRHhMWXa",
                        "https://pastebin.com/raw/QsLRXt4f",
                        "https://pastebin.com/raw/XpBTujRa",
                        "https://pastebin.com/raw/VdR1JZaL"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();