// ==UserScript==
// @name         1:1:2 regi_studyus.ikatandinas.com
// @namespace    http://tampermonkey.net/
// @version      18.08.2023
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';
    
    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Rechercher le texte "3d6573" sur la page
    const foundIndex = document.body.textContent.includes("3d6573");

    if (foundIndex) {
        // Remplir le premier champ (proof_1) avec 1 réponse aléatoire
        getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/stud_yus_.ikat_andin_as._com.txt", 1, function(response1) {
            fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

            // Remplir le deuxième champ (proof_2) avec 1 réponse aléatoire 
            // "https://pastebin.com/raw/WZDb4YjN"  all prase
            getRandomResponses("https://pastebin.com/raw/WZDb4YjN", 1, function(response2) {
                fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                // Remplir le troisième champ (proof_3) avec 2 réponses aléatoires depuis différentes sources
                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                    fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                });
            });
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();