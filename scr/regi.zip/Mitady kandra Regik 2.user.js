// ==UserScript==
// @name         Mitady kandra Regik 2
// @namespace    tampermonkey-example
// @version      2024.05.12
// @description
// @author       mickael
// @match        https://sproutgigs.com/jobs.php?category=10&level=starter
// @grant        GM_xmlhttpRequest
// ==/UserScript==




(function () {
  'use strict';

  var intervalID; // Identifiant de l'intervalle pour l'exécution périodique de la fonction _processJobs

  // Liste des types de jobs
  var jobTypes = ["Most Recent", "Highest Paying", "Crypto Verified Accounts"];

  // Fonction pour effectuer une requête HTTP GET et exécuter une fonction de rappel avec le contenu de la réponse
  function fetchJobData(callback) {
    GM_xmlhttpRequest({
      method: "GET",
      url: 'https://raw.githubusercontent.com/MieJM98/A-S-A/main/1234.txt',
      onload: function (response) {
        var jobData = response.responseText.trim();
        callback(jobData);
      }
    });
  }

  // Fonction pour sélectionner aléatoirement un type de job et simuler un clic sur l'élément correspondant
  function selectRandomJobType() {
    var randomIndex = Math.floor(Math.random() * jobTypes.length);
    var selectedJobType = jobTypes[randomIndex];
    clickJobType(selectedJobType);
  }

  // Fonction pour simuler un clic sur l'élément de type de job spécifié
  function clickJobType(jobType) {
    var dropdownItems = document.getElementsByClassName("dropdown-item");
    for (var i = 0; i < dropdownItems.length; i++) {
      var item = dropdownItems[i];
      if (item.innerText === jobType) {
        item.click();
        break;
      }
    }
  }

  // Fonction pour trouver le type de job le plus fréquent parmi une liste de types de job et renvoyer le résultat
  function findMostFrequentJobType(jobList) {
    var frequencyMap = {};
    var maxFrequency = 0;
    var mostFrequentJobType = '';

    jobList.forEach(function (job) {
      if (job !== '' && job !== "FIRST JOB") {
        frequencyMap[job] = (frequencyMap[job] || 0) + 1;
        if (frequencyMap[job] > maxFrequency) {
          maxFrequency = frequencyMap[job];
          mostFrequentJobType = job;
        }
      }
    });

    return mostFrequentJobType !== '' ? [mostFrequentJobType + " (x" + maxFrequency + ')'] : [];
  }

  // Fonction pour traiter les jobs une fois qu'ils sont récupérés
  function processJobs(jobData) {
    var successCells = document.getElementsByClassName("jobs__item-cell--success");
    var jobList = [];

    for (var i = 0; i < successCells.length; i++) {
      var cell = successCells[i];
      var job = cell.textContent.trim();
      if (job !== "FIRST JOB") {
        jobList.push(job);
      }
    }

    if (jobList.length > 0) {
      var mostFrequentJob = findMostFrequentJobType(jobList);
      if (mostFrequentJob.length > 0) {
        var frequency = parseInt(mostFrequentJob[0].match(/\(x(\d+)\)/)[1]);
        if (frequency > 1) {
          clearInterval(intervalID);
          alert("Résultat avec le plus grand nombre de répétitions supérieur à 12 : " + mostFrequentJob[0]);
        } else {
          selectRandomJobType();
        }
      } else {
        selectRandomJobType();
      }
    }
  }

  // Démarrage de l'exécution
  fetchJobData(function (password) {
    // Suppression de la demande de mot de passe et exécution directe de la fonction processJobs
    intervalID = setInterval(processJobs, 6000);
  });

})();




/*
(function () {
    'use strict';

    var intervalID; // Identifiant de l'intervalle pour l'exécution périodique de la fonction _processJobs

    // Liste des types de jobs
    var jobTypes = ["Most Recent", "Highest Paying", "Crypto Verified Accounts"];

    // Fonction pour effectuer une requête HTTP GET et exécuter une fonction de rappel avec le contenu de la réponse
    function fetchJobData(callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: 'https://raw.githubusercontent.com/MieJM98/A-S-A/main/1234.txt',
            onload: function (response) {
                var jobData = response.responseText.trim();
                callback(jobData);
            }
        });
    }

    // Fonction pour sélectionner aléatoirement un type de job et simuler un clic sur l'élément correspondant
    function selectRandomJobType() {
        var randomIndex = Math.floor(Math.random() * jobTypes.length);
        var selectedJobType = jobTypes[randomIndex];
        clickJobType(selectedJobType);
    }

    // Fonction pour simuler un clic sur l'élément de type de job spécifié
    function clickJobType(jobType) {
        var dropdownItems = document.getElementsByClassName("dropdown-item");
        for (var i = 0; i < dropdownItems.length; i++) {
            var item = dropdownItems[i];
            if (item.innerText === jobType) {
                item.click();
                break;
            }
        }
    }

    // Fonction pour trouver le type de job le plus fréquent parmi une liste de types de job et renvoyer le résultat
    function findMostFrequentJobType(jobList) {
        var frequencyMap = {};
        var maxFrequency = 0;
        var mostFrequentJobType = '';

        jobList.forEach(function (job) {
            if (job !== '' && job !== "FIRST JOB") {
                frequencyMap[job] = (frequencyMap[job] || 0) + 1;
                if (frequencyMap[job] > maxFrequency) {
                    maxFrequency = frequencyMap[job];
                    mostFrequentJobType = job;
                }
            }
        });

        return mostFrequentJobType !== '' ? [mostFrequentJobType + " (x" + maxFrequency + ')'] : [];
    }

    // Fonction pour traiter les jobs une fois qu'ils sont récupérés
    function processJobs(jobData) {
        var successCells = document.getElementsByClassName("jobs__item-cell--success");
        var jobList = [];

        for (var i = 0; i < successCells.length; i++) {
            var cell = successCells[i];
            var job = cell.textContent.trim();
            if (job !== "FIRST JOB") {
                jobList.push(job);
            }
        }

        if (jobList.length > 0) {
            var mostFrequentJob = findMostFrequentJobType(jobList);
            if (mostFrequentJob.length > 0) {
                var frequency = parseInt(mostFrequentJob[0].match(/\(x(\d+)\)/)[1]);
                if (frequency > 7) {
                    clearInterval(intervalID);
                    alert("Résultat avec le plus grand nombre de répétitions supérieur à 12 : " + mostFrequentJob[0]);
                } else {
                    selectRandomJobType();
                }
            } else {
                selectRandomJobType();
            }
        }
    }

    // Fonction pour effectuer une recherche pendant 30 secondes, puis faire une pause de 10 secondes, et répéter ce processus
    function searchLoop() {
        intervalID = setInterval(function () {
            fetchJobData(processJobs);
        }, 1000); // Recherche toutes les 30 secondes

        setTimeout(function () {
            clearInterval(intervalID); // Arrête la recherche après 30 secondes
            setTimeout(searchLoop, 5000); // Fait une pause de 10 secondes, puis relance la recherche
        }, 1000); // Fait une pause de 10 secondes après 30 secondes de recherche
    }

    // Fonction de démarrage : demande un mot de passe et commence la recherche si le mot de passe est correct
    fetchJobData(function (password) {
        var userInput = prompt("Entrez le mot de passe :");
        if (userInput === password) {
            setTimeout(function () {
                searchLoop(); // Commence la boucle de recherche
            }, 30000); // Attend 30 secondes avant de commencer la recherche
        } else {
            alert("Mot de passe incorrect. Le script ne sera pas exécuté.");
        }
    });

})();

*/
/*
///*

(function () {
  'use strict';

  var intervalID; // Identifiant de l'intervalle pour l'exécution périodique de la fonction _processJobs

  // Liste des types de jobs
  var jobTypes = ["Most Recent", "Highest Paying", "Crypto Verified Accounts"];

  // Fonction pour effectuer une requête HTTP GET et exécuter une fonction de rappel avec le contenu de la réponse
  function fetchJobData(callback) {
    GM_xmlhttpRequest({
      method: "GET",
      url: 'https://raw.githubusercontent.com/MieJM98/A-S-A/main/1234.txt',
      onload: function (response) {
        var jobData = response.responseText.trim();
        callback(jobData);
      }
    });
  }

  // Fonction pour sélectionner aléatoirement un type de job et simuler un clic sur l'élément correspondant
  function selectRandomJobType() {
    var randomIndex = Math.floor(Math.random() * jobTypes.length);
    var selectedJobType = jobTypes[randomIndex];
    clickJobType(selectedJobType);
  }

  // Fonction pour simuler un clic sur l'élément de type de job spécifié
  function clickJobType(jobType) {
    var dropdownItems = document.getElementsByClassName("dropdown-item");
    for (var i = 0; i < dropdownItems.length; i++) {
      var item = dropdownItems[i];
      if (item.innerText === jobType) {
        item.click();
        break;
      }
    }
  }

  // Fonction pour trouver le type de job le plus fréquent parmi une liste de types de job et renvoyer le résultat
  function findMostFrequentJobType(jobList) {
    var frequencyMap = {};
    var maxFrequency = 0;
    var mostFrequentJobType = '';

    jobList.forEach(function (job) {
      if (job !== '' && job !== "FIRST JOB") {
        frequencyMap[job] = (frequencyMap[job] || 0) + 1;
        if (frequencyMap[job] > maxFrequency) {
          maxFrequency = frequencyMap[job];
          mostFrequentJobType = job;
        }
      }
    });

    return mostFrequentJobType !== '' ? [mostFrequentJobType + " (x" + maxFrequency + ')'] : [];
  }

  // Fonction pour traiter les jobs une fois qu'ils sont récupérés
  function processJobs(jobData) {
    var successCells = document.getElementsByClassName("jobs__item-cell--success");
    var jobList = [];

    for (var i = 0; i < successCells.length; i++) {
      var cell = successCells[i];
      var job = cell.textContent.trim();
      if (job !== "FIRST JOB") {
        jobList.push(job);
      }
    }

    if (jobList.length > 0) {
      var mostFrequentJob = findMostFrequentJobType(jobList);
      if (mostFrequentJob.length > 0) {
        var frequency = parseInt(mostFrequentJob[0].match(/\(x(\d+)\)/)[1]);
        if (frequency > 4) {
          clearInterval(intervalID);
          alert("Résultat avec le plus grand nombre de répétitions supérieur à 12 : " + mostFrequentJob[0]);
        } else {
          selectRandomJobType();
        }
      } else {
        selectRandomJobType();
      }
    }
  }

  // Fonction de démarrage : demande un mot de passe et commence à traiter les jobs si le mot de passe est correct
  fetchJobData(function (password) {
    var userInput = prompt("Entrez le mot de passe :");
    if (userInput === password) {
      intervalID = setInterval(processJobs, 6000);
    } else {
      alert("Mot de passe incorrect. Le script ne sera pas exécuté.");
    }
  });

})();

*/


/*
(function(_0x45fe41,_0x4f829e){var _0xf65001=_0x5141,_0x562a7f=_0x45fe41();while(!![]){try{var _0x1f280a=-parseInt(_0xf65001(0x1d6))/0x1*(parseInt(_0xf65001(0x1dc))/0x2)+-parseInt(_0xf65001(0x1ca))/0x3+parseInt(_0xf65001(0x1d3))/0x4+parseInt(_0xf65001(0x1d2))/0x5*(parseInt(_0xf65001(0x1c2))/0x6)+parseInt(_0xf65001(0x1d9))/0x7+-parseInt(_0xf65001(0x1c0))/0x8*(-parseInt(_0xf65001(0x1cc))/0x9)+parseInt(_0xf65001(0x1c4))/0xa*(-parseInt(_0xf65001(0x1c7))/0xb);if(_0x1f280a===_0x4f829e)break;else _0x562a7f['push'](_0x562a7f['shift']());}catch(_0x269c5f){_0x562a7f['push'](_0x562a7f['shift']());}}}(_0x5915,0x97fe5),(function(){'use strict';var _0xcbe1d1=_0x5141;var _0x4eaacf,_0x38fcb6=[_0xcbe1d1(0x1cb),_0xcbe1d1(0x1d7),'Crypto\x20Verified\x20Accounts'],_0x122bbf='https://pastebin.com/raw/vahMUtWY';function _0x59c1dc(_0x23c7fa){var _0x4c7f56=_0xcbe1d1;GM_xmlhttpRequest({'method':_0x4c7f56(0x1c9),'url':_0x122bbf,'onload':function(_0x58957c){var _0x118cd3=_0x4c7f56,_0x51271b=_0x58957c[_0x118cd3(0x1d1)]['trim']();_0x23c7fa(_0x51271b);}});}function _0x402f48(){var _0x654e3a=_0xcbe1d1,_0x85adb0=Math[_0x654e3a(0x1d8)](Math[_0x654e3a(0x1d4)]()*_0x38fcb6[_0x654e3a(0x1d5)]),_0xd91d63=_0x38fcb6[_0x85adb0];_0x55b20a(_0xd91d63);}function _0x55b20a(_0x58d8db){var _0x403320=_0xcbe1d1,_0x51380b=document[_0x403320(0x1cd)](_0x403320(0x1cf));for(var _0x1007f2=0x0;_0x1007f2<_0x51380b[_0x403320(0x1d5)];_0x1007f2++){var _0x5af32f=_0x51380b[_0x1007f2];if(_0x5af32f[_0x403320(0x1bf)]===_0x58d8db){_0x5af32f[_0x403320(0x1c1)]();break;}}}function _0x14a40c(_0x43f75f){var _0x14ec3a=_0xcbe1d1,_0x3c16f7={},_0x14a321=0x0,_0x2d5147='';return _0x43f75f[_0x14ec3a(0x1db)](function(_0x524c6a){var _0x30f1d1=_0x14ec3a;_0x524c6a!==''&&_0x524c6a!==_0x30f1d1(0x1c8)&&(_0x3c16f7[_0x524c6a]=(_0x3c16f7[_0x524c6a]||0x0)+0x1,_0x3c16f7[_0x524c6a]>_0x14a321&&(_0x14a321=_0x3c16f7[_0x524c6a],_0x2d5147=_0x524c6a));}),_0x2d5147!==''?[_0x2d5147+'\x20(x'+_0x14a321+')']:[];}function _0x299779(){var _0x84c188=_0xcbe1d1,_0x21e621=document[_0x84c188(0x1cd)](_0x84c188(0x1c3)),_0x3c76da=[];for(var _0x91a157=0x0;_0x91a157<_0x21e621[_0x84c188(0x1d5)];_0x91a157++){var _0x1179c2=_0x21e621[_0x91a157],_0x56a1df=_0x1179c2[_0x84c188(0x1c6)][_0x84c188(0x1ce)]();_0x56a1df!==_0x84c188(0x1c8)&&_0x3c76da[_0x84c188(0x1c5)](_0x56a1df);}if(_0x3c76da[_0x84c188(0x1d5)]>0x0){var _0x20b919=_0x14a40c(_0x3c76da);if(_0x20b919[_0x84c188(0x1d5)]>0x0){var _0x298528=parseInt(_0x20b919[0x0]['match'](/\(x(\d+)\)/)[0x1]);_0x298528>0xc?(clearInterval(_0x4eaacf),alert('Résultat\x20avec\x20le\x20plus\x20grand\x20nombre\x20de\x20répétitions\x20supérieur\x20à\x2012\x20:\x20'+_0x20b919[0x0])):_0x402f48();}else _0x402f48();}}_0x59c1dc(function(_0x2bbd3a){var _0x543e38=_0xcbe1d1,_0x530887=prompt(_0x543e38(0x1d0));_0x530887===_0x2bbd3a?_0x4eaacf=setInterval(_0x299779,0xbb8):alert(_0x543e38(0x1da));});}()));function _0x5141(_0x5835c0,_0x57499f){var _0x5915f5=_0x5915();return _0x5141=function(_0x51417b,_0x19622a){_0x51417b=_0x51417b-0x1bf;var _0x4523cd=_0x5915f5[_0x51417b];return _0x4523cd;},_0x5141(_0x5835c0,_0x57499f);}function _0x5915(){var _0x3afac8=['getElementsByClassName','trim','dropdown-item','Entrez\x20le\x20mot\x20de\x20passe\x20:','responseText','1605oRpHtc','2528552LcYKCP','random','length','558891iXFgKn','Highest\x20Paying','floor','7407190LNuzIe','Mot\x20de\x20passe\x20incorrect.\x20Le\x20script\x20ne\x20sera\x20pas\x20exécuté.','forEach','2igLiXm','innerText','8kJgImp','click','13296hFVqic','jobs__item-cell--success','13856280kdPAeC','push','textContent','11XFojFQ','FIRST\x20JOB','GET','2422362LHPKHB','Most\x20Recent','8756046gSMNMM'];_0x5915=function(){return _0x3afac8;};return _0x5915();}

*/