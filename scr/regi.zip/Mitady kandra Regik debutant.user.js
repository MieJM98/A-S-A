// ==UserScript==
// @name         Mitady kandra Regik debutant
// @namespace    tampermonkey-example
// @version      2024.07.18
// @description
// @author       mickael
// @match        https://sproutgigs.com/jobs.php?category=10&level=starter&sort=
// @grant        GM_xmlhttpRequest
// ==/UserScript==




(function () {
  'use strict';

  var intervalID; // Identifiant de l'intervalle pour l'exécution périodique de la fonction _processJobs

  // Liste des types de jobs
  var jobTypes = ["Most Recent", "Highest Paying", "Crypto Verified Accounts"];

  // Fonction pour effectuer une requête HTTP GET et exécuter une fonction de rappel avec le contenu de la réponse
  function fetchJobData(callback) {
    GM_xmlhttpRequest({
      method: "GET",
      url: 'https://raw.githubusercontent.com/MieJM98/A-S-A/main/1234.txt',
      onload: function (response) {
        var jobData = response.responseText.trim();
        callback(jobData);
      }
    });
  }

  // Fonction pour sélectionner aléatoirement un type de job et simuler un clic sur l'élément correspondant
  function selectRandomJobType() {
    var randomIndex = Math.floor(Math.random() * jobTypes.length);
    var selectedJobType = jobTypes[randomIndex];
    clickJobType(selectedJobType);
  }

  // Fonction pour simuler un clic sur l'élément de type de job spécifié
  function clickJobType(jobType) {
    var dropdownItems = document.getElementsByClassName("dropdown-item");
    for (var i = 0; i < dropdownItems.length; i++) {
      var item = dropdownItems[i];
      if (item.innerText === jobType) {
        item.click();
        break;
      }
    }
  }

  // Fonction pour trouver le type de job le plus fréquent parmi une liste de types de job et renvoyer le résultat
  function findMostFrequentJobType(jobList) {
    var frequencyMap = {};
    var maxFrequency = 0;
    var mostFrequentJobType = '';

    jobList.forEach(function (job) {
      if (job !== '' && job !== "FIRST JOB") {
        frequencyMap[job] = (frequencyMap[job] || 0) + 1;
        if (frequencyMap[job] > maxFrequency) {
          maxFrequency = frequencyMap[job];
          mostFrequentJobType = job;
        }
      }
    });

    return mostFrequentJobType !== '' ? [mostFrequentJobType + " (x" + maxFrequency + ')'] : [];
  }

  // Fonction pour traiter les jobs une fois qu'ils sont récupérés  jobs__item-cell--success
  function processJobs(jobData) {
    var successCells = document.getElementsByClassName("jobs__item-cell--done");
    var jobList = [];

    for (var i = 0; i < successCells.length; i++) {
      var cell = successCells[i];
      var job = cell.textContent.trim();
      if (job !== "FIRST JOB") {
        jobList.push(job);
      }
    }

    if (jobList.length > 0) {
      var mostFrequentJob = findMostFrequentJobType(jobList);
      if (mostFrequentJob.length > 0) {
        var frequency = parseInt(mostFrequentJob[0].match(/\(x(\d+)\)/)[1]);
        if (frequency > 3) {
          clearInterval(intervalID);
          alert("Résultat avec le plus grand nombre de répétitions supérieur à 12 : " + mostFrequentJob[0]);
        } else {
          selectRandomJobType();
        }
      } else {
        selectRandomJobType();
      }
    }
  }

  // Démarrage de l'exécution
  fetchJobData(function (password) {
    // Suppression de la demande de mot de passe et exécution directe de la fonction processJobs
    intervalID = setInterval(processJobs, 6000);
  });

})();


