// ==UserScript==
// @name         1.1.1.1-
// @namespace    http://tampermonkey.net/--https://unidosenoracion.org/
// @version      2024.04.20--17:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Fonction pour remplir le formulaire avec une réponse
    function fillFormWithResponse(response, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = response;
        }
    }

    // Vérifier si l'URL spécifique est trouvée sur la page
    const foundIndex = document.body.textContent.includes("http:/ /tin   yurl  .com/23      sar7zje");

    // Si l'URL est trouvée, procéder avec le script
    if (foundIndex) {
        // Définir le lien externe pour le message
        const messageURL = "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/j.a.s.c.777/unido_senor_acion_.org/m.txt";

        // Charger le message depuis le lien externe
        GM_xmlhttpRequest({
            method: "GET",
            url: messageURL,
            onload: function(response) {
                if (response.status === 200) {
                    const message = response.responseText.trim();
                    // Afficher le message
                    alert(message);
                    // Continuer avec le remplissage du formulaire...
                    GM_xmlhttpRequest({
                        method: "GET",
                        url: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/j.a.s.c.777/unido_senor_acion_.org/cd.txt",
                        onload: function(response) {
                            if (response.status === 200) {
                                const responses = response.responseText.trim().split("\n");
                                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                                fillFormWithResponse(randomResponse, 'textarea#vproof.form-control');

                                // Charger les réponses pour le textarea#proof_1.form-control.alert-on-type-task
                                GM_xmlhttpRequest({
                                    method: "GET",
                                    url: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/b._jaka_rta_studio_.com/lnk.txt",
                                    onload: function(response) {
                                        if (response.status === 200) {
                                            const responses = response.responseText.trim().split("\n");
                                            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                                            fillFormWithResponse(randomResponse, 'textarea#proof_1.form-control.alert-on-type-task');

                                            // Récupérer les réponses pour les autres preuves depuis des liens externes
                                            const links = [
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/360_global_transportation_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/360_global_transportation_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/360_global_transportation_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/4_seasons_equip_.ca/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/4_seasons_equip_.ca/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/4_seasons_equip_.ca/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/Abile_nefoode_xpress_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/Abile_nefoode_xpress_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/Abile_nefoode_xpress_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/acti_vecam_paign_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/acti_vecam_paign_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/acti_vecam_paign_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ait_ecsa_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ait_ecsa_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ait_ecsa_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/alli_anz-_assis_tance_.ie/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/alli_anz-_assis_tance_.ie/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/alli_anz-_assis_tance_.ie/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ama_zon_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ama_zon_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ama_zon_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/aquag_lobal_.co_.uk/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/aquag_lobal_.co_.uk/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/aquag_lobal_.co_.uk/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/arrow_head_manor_hotel_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/arrow_head_manor_hotel_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/arrow_head_manor_hotel_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/atti_cuse_xcha_nge_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/atti_cuse_xcha_nge_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/atti_cuse_xcha_nge_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/badis_cher_-landes_verein_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/badis_cher_-landes_verein_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/badis_cher_-landes_verein_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/beforward_.jp/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/beforward_.jp/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/beforward_.jp/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/biblical_counse_lingin_sights_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/biblical_counse_lingin_sights_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/biblical_counse_lingin_sights_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bid._wis_consin_sur_plus._com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bid._wis_consin_sur_plus._com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bid._wis_consin_sur_plus._com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bio_legio_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bio_legio_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bio_legio_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/blue-_hori_zon_.gr/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/blue-_hori_zon_.gr/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/blue-_hori_zon_.gr/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bria_nai_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bria_nai_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bria_nai_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bro_dovi_.hr/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bro_dovi_.hr/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bro_dovi_.hr/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bs_power_.co_.za/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bs_power_.co_.za/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bs_power_.co_.za/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm-_europe_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm-_europe_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm-_europe_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm_industrial_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm_industrial_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm_industrial_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/buffet_lour_enco_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/buffet_lour_enco_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/buffet_lour_enco_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/burst_of_class_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/burst_of_class_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/burst_of_class_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/business_.google_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/business_.google_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/business_.google_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/can_com_.at/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/can_com_.at/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/can_com_.at/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cedre_.org/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cedre_.org/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cedre_.org/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cef-_france_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cef-_france_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cef-_france_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/conservator_iosa_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/conservator_iosa_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/conservator_iosa_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cse_occupational_hygiene._co._za/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cse_occupational_hygiene._co._za/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cse_occupational_hygiene._co._za/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cura_con_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cura_con_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cura_con_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/custom_gpt._ai/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/custom_gpt._ai/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/custom_gpt._ai/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/delta_-t._co._uk/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/delta_-t._co._uk/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/delta_-t._co._uk/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/denis_on_consulting_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/denis_on_consulting_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/denis_on_consulting_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/des_fran_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/des_fran_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/des_fran_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/disney_land_paris_transfer_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/disney_land_paris_transfer_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/disney_land_paris_transfer_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dive_2_gether_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dive_2_gether_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dive_2_gether_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dn_ck_.gr/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dn_ck_.gr/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dn_ck_.gr/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/doc_freak_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/doc_freak_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/doc_freak_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dreamfly_.com_.hk/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dreamfly_.com_.hk/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dreamfly_.com_.hk/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/el_more_indian_art_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/el_more_indian_art_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/el_more_indian_art_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exmo_ort_rim._co._uk/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exmo_ort_rim._co._uk/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exmo_ort_rim._co._uk/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exo-_hotel-_heidelberg_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exo-_hotel-_heidelberg_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exo-_hotel-_heidelberg_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/filmora_.wonder_share_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/filmora_.wonder_share_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/filmora_.wonder_share_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/for-a_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/for-a_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/for-a_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/glossy_glamour_glam_hair_extension_salon_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/glossy_glamour_glam_hair_extension_salon_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/glossy_glamour_glam_hair_extension_salon_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gozo_ypaz._mx/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gozo_ypaz._mx/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gozo_ypaz._mx/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gsgl_itzy_galleria_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gsgl_itzy_galleria_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gsgl_itzy_galleria_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gulf_news_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gulf_news_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gulf_news_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/heat_switch_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/heat_switch_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/heat_switch_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/helpy_robotics_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/helpy_robotics_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/helpy_robotics_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/holly_wood_lace_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/holly_wood_lace_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/holly_wood_lace_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hotel_hosta_lillo_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hotel_hosta_lillo_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hotel_hosta_lillo_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hyper_scalers_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hyper_scalers_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hyper_scalers_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ime_rit_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ime_rit_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ime_rit_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ip_sorex_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ip_sorex_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ip_sorex_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ir_muk_.co_.uk/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ir_muk_.co_.uk/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ir_muk_.co_.uk/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/issue_wire_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/issue_wire_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/issue_wire_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/jean_cariel_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/jean_cariel_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/jean_cariel_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/klapp_erzae_hnchen_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/klapp_erzae_hnchen_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/klapp_erzae_hnchen_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/koleo_.co.za/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/koleo_.co.za/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/koleo_.co.za/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laser_data_.at/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laser_data_.at/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laser_data_.at/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laurao_xossi_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laurao_xossi_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laurao_xossi_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/layer_.it/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/layer_.it/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/layer_.it/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lor_enz_.cc/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lor_enz_.cc/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lor_enz_.cc/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lot._dhl._com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lot._dhl._com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lot._dhl._com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lp_site._grupo_voalle_.com.br/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lp_site._grupo_voalle_.com.br/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lp_site._grupo_voalle_.com.br/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mac-_solutions_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mac-_solutions_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mac-_solutions_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mail_chi_.mp/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mail_chi_.mp/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mail_chi_.mp/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/many_chat_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/many_chat_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/many_chat_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/math_.he_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/math_.he_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/math_.he_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/maxupy_ourads_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/maxupy_ourads_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/maxupy_ourads_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mind_theory_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mind_theory_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mind_theory_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mise_reor_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mise_reor_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mise_reor_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/miss_orisu_ites_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/miss_orisu_ites_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/miss_orisu_ites_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/net_tita_kka_.fi/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/net_tita_kka_.fi/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/net_tita_kka_.fi/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nirva_name_diaso_lutions_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nirva_name_diaso_lutions_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nirva_name_diaso_lutions_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nj_recovery_coach._co/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nj_recovery_coach._co/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nj_recovery_coach._co/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nordi_cout_door_.ee/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nordi_cout_door_.ee/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nordi_cout_door_.ee/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/north_parkave_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/north_parkave_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/north_parkave_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/open_gear_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/open_gear_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/open_gear_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/optima_.nc/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/optima_.nc/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/optima_.nc/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/papa_sand_beer_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/papa_sand_beer_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/papa_sand_beer_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/paul_ownia_france_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/paul_ownia_france_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/paul_ownia_france_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/peak_provi_sions_grocer_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/peak_provi_sions_grocer_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/peak_provi_sions_grocer_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/pro_ject_-n_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/pro_ject_-n_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/pro_ject_-n_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ptw_dos_imetry_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ptw_dos_imetry_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ptw_dos_imetry_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/r-_tec_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/r-_tec_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/r-_tec_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/rca_theme_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/rca_theme_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/rca_theme_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/recoverit_.wonder_share_.net/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/recoverit_.wonder_share_.net/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/recoverit_.wonder_share_.net/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/reuni_loc._com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/reuni_loc._com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/reuni_loc._com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/richard_-_burdett_.pixels_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/richard_-_burdett_.pixels_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/richard_-_burdett_.pixels_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sagi_capri_produtora_.com_.br/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sagi_capri_produtora_.com_.br/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sagi_capri_produtora_.com_.br/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sailing_-tech_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sailing_-tech_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sailing_-tech_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/salam_store_-ksa_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/salam_store_-ksa_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/salam_store_-ksa_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/scd_key_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/scd_key_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/scd_key_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/selt._language_cert_.org/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/selt._language_cert_.org/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/selt._language_cert_.org/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/silicon_expert_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/silicon_expert_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/silicon_expert_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stah_lbau-_menke_.de/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stah_lbau-_menke_.de/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stah_lbau-_menke_.de/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stein_muller_africa._com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stein_muller_africa._com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stein_muller_africa._com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stel_late_.co/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stel_late_.co/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stel_late_.co/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/steri_line_.it/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/steri_line_.it/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/steri_line_.it/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tech_target_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tech_target_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tech_target_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/test_.be/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/test_.be/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/test_.be/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tfi_.co_.za/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tfi_.co_.za/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tfi_.co_.za/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/theer_asure_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/theer_asure_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/theer_asure_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/thorn_hill_safari_lodge_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/thorn_hill_safari_lodge_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/thorn_hill_safari_lodge_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/vacu_umver_damper_.nl/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/vacu_umver_damper_.nl/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/vacu_umver_damper_.nl/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/valve_.va_login_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/valve_.va_login_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/valve_.va_login_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/varme_bar_onen_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/varme_bar_onen_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/varme_bar_onen_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/wein_location_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/wein_location_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/wein_location_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/welcome_estes_park_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/welcome_estes_park_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/welcome_estes_park_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xen_arc_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xen_arc_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xen_arc_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xga_mess_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xga_mess_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xga_mess_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/yach_tingmy_konos_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/yach_tingmy_konos_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/yach_tingmy_konos_.com/pg.txt"
                                                },
                                                {
                                                    proof1: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/youtube_.com/ad.txt",
                                                    proof2: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/youtube_.com/pg.txt",
                                                    proof3: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/youtube_.com/pg.txt"
                                                }

                                            ];

                                            // Choix aléatoire d'un lien
                                            const randomLink = links[Math.floor(Math.random() * links.length)];

                                            // Promesse pour charger les réponses de proof1
                                            const promise1 = new Promise((resolve, reject) => {
                                                GM_xmlhttpRequest({
                                                    method: "GET",
                                                    url: randomLink.proof1,
                                                    onload: function(response) {
                                                        if (response.status === 200) {
                                                            const proof1Response = response.responseText.trim();
                                                            const proof1Responses = proof1Response.split("\n");
                                                            const randomProof1Response = proof1Responses[Math.floor(Math.random() * proof1Responses.length)];
                                                            resolve(randomProof1Response);
                                                        } else {
                                                            reject('Échec de chargement des réponses pour proof1.');
                                                        }
                                                    }
                                                });
                                            });

                                            const promise2 = new Promise((resolve, reject) => {
                                                GM_xmlhttpRequest({
                                                    method: "GET",
                                                    url: randomLink.proof2,
                                                    onload: function(response) {
                                                        if (response.status === 200) {
                                                            const proof2Response = response.responseText.trim();
                                                            const proof2Responses = proof2Response.split("\n");
                                                            const randomProof2Response = proof2Responses[Math.floor(Math.random() * proof2Responses.length)];
                                                            resolve(randomProof2Response);
                                                        } else {
                                                            reject('Échec de chargement des réponses pour proof1.');
                                                        }
                                                    }
                                                });
                                            });

                                            const promise3 = new Promise((resolve, reject) => {
                                                GM_xmlhttpRequest({
                                                    method: "GET",
                                                    url: randomLink.proof3,
                                                    onload: function(response) {
                                                        if (response.status === 200) {
                                                            const proof3Response = response.responseText.trim();
                                                            const proof3Responses = proof3Response.split("\n");
                                                            const randomProof3Response = proof3Responses[Math.floor(Math.random() * proof3Responses.length)];
                                                            resolve(randomProof3Response);
                                                        } else {
                                                            reject('Échec de chargement des réponses pour proof1.');
                                                        }
                                                    }
                                                });
                                            });

                                            // Attendre que toutes les promesses soient résolues
                                            Promise.all([promise1, promise2, promise3])
                                                .then(values => {
                                                    // Combinez les réponses avec des sauts de ligne
                                                    const combinedResponse = `${values[0]}\n${values[1]}\n${values[2]}`;
                                                    // Remplir le textarea avec les réponses combinées
                                                    fillFormWithResponse(combinedResponse, 'textarea#proof_2.form-control.alert-on-type-task');
                                                })
                                                .catch(error => {
                                                    console.error(error);
                                                });
                                        } else {
                                            console.error('Échec de chargement des réponses pour le formulaire principal.');
                                        }
                                    }
                                });
                            } else {
                                console.error('Échec de chargement du message.');
                            }
                        }
                    });
                } else {
                    console.error('Échec de chargement du message.');
                }
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }
})();


