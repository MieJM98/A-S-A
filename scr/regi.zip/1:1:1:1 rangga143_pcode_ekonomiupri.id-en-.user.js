// ==UserScript==
// @name         1:1:1:1 rangga143_pcode_ekonomiupri.id/en/
// @namespace    http://tampermonkey.net/--https://ekonomiupri.id/en/
// @version      2024.01.17--06:30
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


/*

Go to: https://ekonomiupri.id/en/?job=ef348fd8247f&worker=3897c90f
Visit the internal link to get to my website "READ MORE" (my website : e*on*mi*pri.id/e*)
Visit the 1st to 10th articles slowly and you will find next post below
10th articles :  https://ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/
                         ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/
                         ek***mi**ri.id/en/be*t-ho**ls-in-the-un***d-ki***om-un*ei***g-l***ry-and-co**ort/
*/

(function () {
    'use strict';

    // Fonction pour remplir le formulaire avec une réponse
    function fillFormWithResponse(response, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = response;
        }
    }

    // Rechercher le mot "indice" dans la page
    const foundIndice1 = document.body.textContent.includes("https://ekonomiupri.id/en/?job=ef348fd8247f&worker=3897c90f");//3897c90f    katty22
    const foundIndice2 = document.body.textContent.includes("https://ekonomiupri.id/en/?job=ef348fd8247f&worker=909931d0");//909931d0    Mikajm98
    const foundIndice3 = document.body.textContent.includes("https://ekonomiupri.id/en/?job=ef348fd8247f&worker=bd89e38e");//bd89e38e    Nirina11
    const foundIndice4 = document.body.textContent.includes("https://ekonomiupri.id/en/?job=ef348fd8247f&worker=ed8b42c5");//ed8b42c5    Aingarakoto

    if (foundIndice1) {
        // Définir les réponses pour indice1 "3897c90f"  katty22
        const responseProof1 = "https://www.camping.info/de/beliebte-region/costa-brava?utm_medium=cpc&utm_source=google&utm_campaign=1838432532&utm_content=345625934133_c_ekonomiupri.id&utm_term=&gclid=CjwKCAiAkp6tBhB5EiwANTCx1DHGw-QgopqjCEthj1jSavQ24NpPlXXj3OFuun3lwCtTgjio586ekxoCcV0QAvD_BwE";
        const responseProof2 = "https://www.camping.info/de/info/kontakt";
        const responseProof3 = "pw-179b127c2afc1492792a2cbecebab16b2167f80b916b459ea5e13cb2d764cd02";
        const responseProof4 = "ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/";

        // Remplir le formulaire avec les réponses
        fillFormWithResponse(responseProof1, 'textarea#proof_1.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof2, 'textarea#proof_2.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof3, 'textarea#proof_3.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof4, 'textarea#vproof');
    } else if (foundIndice2) {
        // Définir les réponses pour indice2 "909931d0" Mikajm98
        const responseProof1 = "https://www.hotelscombined.com/";
        const responseProof2 = "https://www.hotelscombined.com/contact/";
        const responseProof3 = "pw-f50d893fde469b0a76da281bccf9313d74b3bb705c309f42f9069c60c815eec6";
        const responseProof4 = "ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/";

        // Remplir le formulaire avec les réponses
        fillFormWithResponse(responseProof1, 'textarea#proof_1.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof2, 'textarea#proof_2.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof3, 'textarea#proof_3.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof4, 'textarea#vproof.form-control');
    } else if (foundIndice3) {
        // Définir les réponses pour indice3 "bd89e38e" Nirina11
        const responseProof1 = "https://www.rioluxuryhomes.in/properties.php?gclid=EAIaIQobChMIyvzm5rrkgwMVlGAVCB2nxAh1EAEYASAAEgIZ3fD_BwE";
        const responseProof2 = "https://www.rioluxuryhomes.in/contact-us.php";
        const responseProof3 = "pw-c616530521be26e7c564b6456d5e82eeae80674f4fd60fbcdc32cc89b747b3bb";
        const responseProof4 = "ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/";

        // Remplir le formulaire avec les réponses
        fillFormWithResponse(responseProof1, 'textarea#proof_1.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof2, 'textarea#proof_2.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof3, 'textarea#proof_3.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof4, 'textarea#vproof.form-control');
    } else if (foundIndice4) {
        // Définir les réponses pour indice4 "ed8b42c5" Aingarakoto
        const responseProof1 = "https://www.hotelscombined.com/";
        const responseProof2 = "https://www.hotelscombined.com/contact/";
        const responseProof3 = "pw-e8b6672768fd45cb4493dc7bd024888999cd4ddb01b70da762c6ea45e08bf518";
        const responseProof4 = "ekonomiupri.id/en/best-hotels-in-the-united-kingdom-unveiling-luxury-and-comfort/";

        // Remplir le formulaire avec les réponses
        fillFormWithResponse(responseProof1, 'textarea#proof_1.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof2, 'textarea#proof_2.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof3, 'textarea#proof_3.form-control.alert-on-type-task');
        fillFormWithResponse(responseProof4, 'textarea#vproof.form-control');
    } else {
        console.error('Indice non trouvé.');
    }

})();
