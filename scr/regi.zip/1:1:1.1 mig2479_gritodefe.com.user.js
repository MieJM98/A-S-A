// ==UserScript==
// @name         1:1:1.1 mig2479_gritodefe.com
// @namespace    http://tampermonkey.net/--https://gritodefe.com/
// @version      2023.12.18--10:30
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Fonction pour remplir le formulaire avec une réponse
    function fillFormWithResponse(response, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = response;
        }
    }

    // Rechercher le texte "4a0vgap" sur la page
    const foundIndex = document.body.textContent.includes("4a0vgap");

    if (foundIndex) {
        // Récupérer les réponses pour proof_1 depuis le lien externe
        GM_xmlhttpRequest({
            method: "GET",
            url: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/MIG/grito_defe_.com.txt",
            onload: function(response) {
                const responses = response.responseText.trim().split("\n");
                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                fillFormWithResponse(randomResponse, 'textarea#proof_1.form-control.alert-on-type-task');

                // Définir les réponses pour les autres preuves
                const otherResponses = {
                    var1: {
                        proof2: "https://www.2flyairborne.com/contact-us/",
                        proof3: "Leave your contact information below and one of our knowledgeable training advisors will contact you.",
                        proof4: "Our students are exposed to a variety of instrument approach procedures and gain extensive radio communication practice, ensuring the finest training available."
                    },
                    var2: {
                        proof2: "https://www.abe.co.za/contact-abe-construction-chemicals/",
                        proof3: "There are no jobs available at a.b.e. please do not use the contact form to send your CV.",
                        proof4: "a.b.e.®, with head office in Boksburg, is proud to be part of the construction brands of SAINT-GOBAIN, worldwide."
                    },
                    var3: {
                        proof2: "https://www.jntechenergy.com/contact-us_d2",
                        proof3: "If you are interested in our products and want to know more details,please leave a message here,we will reply you as soon as we can.",
                        proof4: "Adhering to the idea of “Creating green energy future, Ensure the sustainable social development”, JNTECH takes scientific development view as guideline creating green eco-friendly new energy as duty, keeps serving society,people and the national."
                    },
                    var4: {
                        proof2: "https://www.sjecorp.com/contact_us/contact_us.php",
                        proof3: "Our associate will contact you within 24-48 business hours.",
                        proof4: "We are on the same time zone as Seoul and Tokyo (GMT +09:00)."
                    },
                    var5: {
                        proof2: "https://www.tfi.co.za/pages/contact",
                        proof3: "Please complete the following form and we will contact you as soon as possible.",
                        proof4: "TFI is a Level 7 Contributor with a 50% Procurement Recognition Level and are committed to the principles and objectives of Broad-Based Black Economic Empowerment in South Africa. Read more ."
                    },
                    var6: {
                        proof2: "https://www.lws.fr/contact_formulaire.php",
                        proof3: "Nombreuses accréditations et certifications.",
                        proof4: "LWS - Ligne Web Services SAS est une filiale du Groupe LWS, société au capital de 1 000 000 d'Euros immatriculée au RCS de Epinal sous le numéro 450 453 881 2, rue Jules Ferry, 88190 Golbey."
                    },
                    var7: {
                        proof2: "https://www.sarcon.co.za/contact/",
                        proof3: "30 Paul Sauer Street,Bela-Bela, 0480 Postnet Suite 38,  Private Bag X 1604, Bela-Bela, 0480",
                        proof4: "SARCON’s ability to take on challenges resulted in us becoming a multi-disciplinary construction company, providing construction services to the grain industry."
                    },
                    var8: {
                        proof2: "https://rdu.edu.tr/contact/",
                        proof3: "Koşu Yolu St. Yenikent, Gonyeli, Nicosia – North Cyprus P.O. Box 139 Via Mersin 10 – Turkey.",
                        proof4: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind."
                    },
                    var9: {
                        proof2: "https://www.marklogic.com/company/contact/",
                        proof3: "In order to receive support, you must be registered as a MarkLogic Support Contact.",
                        proof4: "Also on this date in 1969, another significant takeoff took place: NASA launched Apollo 10. Coincidence? We think not."
                    },
                    var10: {
                        proof2: "https://www.misterbooking.net/fr/devis-demo/",
                        proof3: "L’un de nos experts vous recontactera dans les plus brefs délais pour vous proposer un rendez-vous.",
                        proof4: "Le support technique est disponible du lundi au vendredi puis permanence en cas d’urgence bloquante les soirs, les week-ends et les jours fériés."
                    },
                    var11: {
                        proof2: "https://betianna.com/contact-us/",
                        proof3: "1801 Polk street unit 224025, Hollywood, Florida, 33022.",
                        proof4: "P.S. All items are thoroughly sanitized before leaving our warehouse."
                    },
                    var12: {
                        proof2: "https://www.gdajcentury.com/contact-us_d2",
                        proof3: "Someone is always there to answer your call during normal business hours.",
                        proof4: "Let's build our glorious future together !"
                    },
                    var13: {
                        proof2: "http://www.kgrrigs.com/contact.php",
                        proof3: "Today, as the market demand is growing for the water well, mining and construction equipment, KGR has began to expand its efforts by developing and manufacturing a wide range of Drilling Machinery for the Water Well Drilling, Blast Hole Drilling, Core Drilling, Geotechnical, Pilling and other Customized Drilling.",
                        proof4: "Since 1992, KGR is a renowned name in manufacturing dth hammers, t.c. button bits, and friction welded & induction hardened drill pipes under the leadership of Mr. K. Govinda Reddy, a technocrat who studied engineering degree (B.Tech) and Management in Business Administration (M.B.A) from reputed universities."
                    }
                };

                // Choisir aléatoirement une variable parmi var1, var2, var3 et var4
                const varNames = Object.keys(otherResponses);
                const randomVarName = varNames[Math.floor(Math.random() * varNames.length)];

                // Remplir le formulaire avec les réponses de la variable choisie
                fillFormWithResponse(otherResponses[randomVarName].proof2, 'textarea#proof_2.form-control.alert-on-type-task');
                fillFormWithResponse(otherResponses[randomVarName].proof3, 'textarea#proof_3.form-control.alert-on-type-task');
                fillFormWithResponse(otherResponses[randomVarName].proof4, 'textarea#proof_4.form-control.alert-on-type-task');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();