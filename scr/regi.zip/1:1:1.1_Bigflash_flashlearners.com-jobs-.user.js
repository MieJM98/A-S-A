// ==UserScript==
// @name         1:1:1.1_Bigflash_flashlearners.com/jobs/
// @namespace    http://tampermonkey.net/--https://flashlearners.com/jobs/
// @version      2024.03.03
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour remplir le formulaire avec une réponse
    function fillFormWithResponse(response, textareaSelector) {
        const textarea = document.querySelector(textareaSelector);
        if (textarea) {
            textarea.value = response;
        }
    }

    // Search: Swift Relocation To Canada As Electronics Engineer 2025
    //Follow EXACTLY This Website: https://snipboard.io/k05AFV.jpg
    //   https://flashlearners.com/jobs/immigration-to-canada-as-electronics-engineer/
    const foundIndex = document.body.textContent.includes("Swift Relocation To Canada As Electronics Engineer 2025");

    if (foundIndex) {
        // Définir les réponses pour proof_1 directement dans le script
        const proof1Response = `0816666`;

// Remplir le formulaire avec la réponse pour proof_1
fillFormWithResponse(proof1Response.trim(), 'textarea#proof_1');

        // Répéter le processus pour proof_2
        // ... (Ajoutez le code pour proof_2 comme suit)

        const proof2Responses = [
             `
Before submitting your Express Entry application, we will assist you in the process of having your qualifications and certificates verified as required by immigration authorities. This will help ensure that you present the most accurate and credible information in your application. No stress immigration to Canada for Geologists learners in 2025.
`,
             `
It is important to note that while specific experience in the field is valuable, a positive attitude, willingness to learn, and dedication to providing excellent service can make up for lack of prior experience. Training programs are often provided by employers to help new employees develop the necessary skills and knowledge to excel in their roles.
`,
            `
Job Skills and Requirements
High school diploma
Good organization skills
Exceptional time management skills
Good communication skills
Pay strong attention to details
Effective interpersonal skills
Good problem solving skills
Friendly an positive attitude
The job description is your opportunity to clearly communicate the requirements and expectations of the role.

Be sure to include detailed information about the tasks the housekeeper will be responsible for, any necessary qualifications or skills, the hours of work, and the salary range. A well-crafted job description will help attract the right candidates.
`,
            `
3. Family sponsorship: If you have a family member who is a US citizen or permanent resident, they can sponsor you to become a permanent resident. Their sponsorship can help you on your path to obtaining permanent residency in the United States
`,
            `
Please note: This article provides a general overview of the process. The specific steps may vary based on the type of immigrant visa you’re applying for. Always consult with a qualified immigration attorney or the official USCIS website for the most accurate and up-to-date information.
`,
            `
If the beneficiary worker is lawfully in the United States, he or she can apply for adjustment of status or finish the processing at a U.S. consulate once the priority date is current as of the date of filing with the US Citizenship and Immigration Services or US Department of Labor.
`,
            `
When you have an interview, don’t drop everything.
Too many people stop applying and reaching out once they’ve been asked for an interview.

This isn’t a good plan! A phone interview or in-person interview is a long way from a job offer, and anything may happen in the interim.

They could hire an internal applicant (you’d be amazed how often that occurs after advertising a position online), their finances might be frozen, there could be a reorganization that changes the recruiting team and goals, or they could be unable to agree on candidates and put the process on pause.
`,
            `
Truck Driver
Truck drivers are important, too. Every time you buy something at the store or online, a truck driver probably helped get it there. They earn about $45,417 a year.

According to Neuvoo, it is one of the best-paying jobs that does not require sitting at a desk, with an average annual salary of $44,561.
`,
            `
With their excellent communication skills, problem-solving abilities, empathy, and proficiency in digital platforms, they ensure positive experiences and customer satisfaction. Their contributions are crucial in fostering strong customer relationships and driving business success. Hope you found this helpful?
`,
            `
By undergoing the Skills and Qualification Assessment, you not only increase your chances of being selected for immigration but also ensure that your skills are recognized and valued in Canada. It streamlines the process of professional registration and enables you to start your career as a computer engineer in Canada without any unnecessary barriers.
`,

        ];

        const randomResponse2 = proof2Responses[Math.floor(Math.random() * proof2Responses.length)];
        fillFormWithResponse(randomResponse2, 'textarea#proof_2');

        // Définir les réponses pour les autres preuves directement dans le script
        const otherResponses = {
                    var1: {
                        proof3: "https://www.2flyairborne.com/about-airborne/",
                        proof4: "https://www.2flyairborne.com/contact-us/"
                    },
                    var2: {
                        proof3: "https://www.abe.co.za/about-abe-construction-chemicals/",
                        proof4: "https://www.abe.co.za/contact-abe-construction-chemicals/"
                    },
                    var3: {
                        proof3: "https://www.jntechenergy.com/about-us_d1",
                        proof4: "https://www.jntechenergy.com/contact-us_d2"
                    },
                    var4: {
                        proof3: "https://www.sjecorp.com/about_us",
                        proof4: "https://www.sjecorp.com/contact_us/contact_us.php"
                    },
                    var5: {
                        proof3: "https://www.tfi.co.za/pages/about-tfi",
                        proof4: "https://www.tfi.co.za/pages/contact"
                    },
                    var6: {
                        proof3: "https://www.lws.fr/a_propos_infos.php",
                        proof4: "https://www.lws.fr/contact_formulaire.php"
                    },
                    var7: {
                        proof3: "https://www.sarcon.co.za/about-us/",
                        proof4: "https://www.sarcon.co.za/contact/"
                    },
                    var8: {
                        proof3: "https://rdu.edu.tr/about-rdu/",
                        proof4: "https://rdu.edu.tr/contact/"
                    },
                    var9: {
                        proof3: "https://www.marklogic.com/company/about/",
                        proof4: "https://www.marklogic.com/company/contact/"
                    },
                    var10: {
                        proof3: "https://www.misterbooking.net/fr/la-societe/",
                        proof4: "https://www.misterbooking.net/fr/devis-demo/"
                    },
                    var11: {
                        proof3: "https://betianna.com/about-us/",
                        proof4: "https://betianna.com/contact-us/"
                    },
                    var12: {
                        proof3: "https://www.gdajcentury.com/about-us_d1",
                        proof4: "https://www.gdajcentury.com/contact-us_d2"
                    },
                    var13: {
                        proof3: "http://www.kgrrigs.com/about.php",
                        proof4: "http://www.kgrrigs.com/contact.php"
                    },
                    var14: {
                        proof3: "https://www.malvernpanalytical.com/en/about-us/",
                        proof4: "https://www.malvernpanalytical.com/en/contact-us/"
                    },
                    var15: {
                        proof3: "https://www.sailing-tech.com/about-us/",
                        proof4: "https://www.sailing-tech.com/contact-us/"
                    },
                    var16: {
                        proof3: "https://rdu.edu.tr/about-us/",
                        proof4: "https://rdu.edu.tr/contact-us/"
                    },
                    var17: {
                        proof3: "https://bluedwarfs.com/en/about-us/",
                        proof4: "https://bluedwarfs.com/en/contact-us/"
                    },
                    var18: {
                        proof3: "https://www.mvps.net/about-us/",
                        proof4: "https://www.mvps.net/contact-us/"
                    },
                    var19: {
                        proof3: "https://betianna.com/about-us/",
                        proof4: "https://betianna.com/contact-us/"
                    },
                    var19: {
                        proof3: "https://gsglitzygalleria.com/about-us/",
                        proof4: "https://gsglitzygalleria.com/contact-us/"
                    }

                        };

        // Choisir aléatoirement une variable parmi var1, var2, var3 et var4
        const varNames = Object.keys(otherResponses);
        const randomVarName = varNames[Math.floor(Math.random() * varNames.length)];

        // Remplir le formulaire avec les réponses de la variable choisie
        fillFormWithResponse(otherResponses[randomVarName].proof3, 'textarea#proof_3');
        fillFormWithResponse(otherResponses[randomVarName].proof4, 'textarea#proof_4');
    } else {
        console.error('Indice non trouvé.');
    }
})();
