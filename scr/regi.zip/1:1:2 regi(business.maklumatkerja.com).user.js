// ==UserScript==
// @name         1:1:2 regi(business.maklumatkerja.com)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(async function() {


})();
