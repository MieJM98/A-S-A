// ==UserScript==
// @name         1:1:2 regi(C)-www.masa.biz.id/eng/
// @namespace    http://tampermonkey.net/--https://www.masa.biz.id/eng/
// @version      2024.08.28--06:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==





(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["mofo---gasy", "https://rebrand.ly/e8cc32"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.masa_.biz_.id%2Beng.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/allstnc.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                        "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            //console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();










(function() {
    'use strict';

    // Function to display a confirmation popup
    function showConfirmationPopup(callback) {
        const shouldFillForm = confirm('CODE t@ 22 mai 2024, 05H00, fenoina ve?');
        callback(shouldFillForm);
    }

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Search for the text "3FcEwtF" on the page  www.masa.biz.id+eng
    const foundIndex = document.body.textContent.includes("e8cc32");

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        showConfirmationPopup(function(shouldFillForm) {
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/www_.masa_.biz_.id%2Beng.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Set the second field to a fixed response
                fillFormWithRandomResponses(["MAS1"], 'textarea#vproof');

                const sources = [
                    "https://pastebin.com/raw/1UBfN03Z",
                    "https://pastebin.com/raw/9SbdJnYs",
                    "https://pastebin.com/raw/tG5Uq3HV",
                    "https://pastebin.com/raw/sCcL4fmc",
                    "https://pastebin.com/raw/khC5ubQ3",
                    "https://pastebin.com/raw/HSSGN2bp",
                    "https://pastebin.com/raw/cvT4CAh9",
                    "https://pastebin.com/raw/bMpidwrb",
                    "https://pastebin.com/raw/0YsMUrcJ",
                    "https://pastebin.com/raw/PJqLfHAH",
                    "https://pastebin.com/raw/XRHhMWXa",
                    "https://pastebin.com/raw/QsLRXt4f",
                    "https://pastebin.com/raw/XpBTujRa",
                    "https://pastebin.com/raw/VdR1JZaL"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

})();
