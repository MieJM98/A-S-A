// ==UserScript==
// @name         1:1:2 regi_maklumatkerja.com/eng/
// @namespace    http://tampermonkey.net/--https://maklumatkerja.com/eng/
// @version      2024.05.30--20:00
// @description  try to take over the world!
// @author       You
// @match        https://sproutgigs.com/jobs/submit-task.php*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sproutgigs.com
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Fonction pour récupérer plusieurs réponses aléatoires depuis une source externe
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Fonction pour remplir le formulaire avec les réponses aléatoires
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

    // Liste des indices à rechercher
    const searchIndices = ["https://rebrand.ly/6y846o1", "xxxxx_xxxx", "sssss_ssss"];

    // Fonction pour rechercher un indice
    function searchForIndex(index) {
        const foundIndex = document.body.textContent.includes(index);

        if (foundIndex) {
            // Remplir les champs du formulaire avec des réponses aléatoires ici
            getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/link.txt", 1, function(response1) {
                fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');

                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/phrs.txt", 1, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');

                    const sources = [
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/360_global_transportation_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/4_seasons_equip_.ca/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/Abile_nefoode_xpress_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/acti_vecam_paign_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ait_ecsa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/alli_anz-_assis_tance_.ie/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ama_zon_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/aquag_lobal_.co_.uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/arrow_head_manor_hotel_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/atti_cuse_xcha_nge_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/badis_cher_-landes_verein_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/beforward_.jp/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/biblical_counse_lingin_sights_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bid._wis_consin_sur_plus._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bio_legio_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/blue-_hori_zon_.gr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bria_nai_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bro_dovi_.hr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bs_power_.co_.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm-_europe_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm_industrial_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/buffet_lour_enco_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/burst_of_class_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/business_.google_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/can_com_.at/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cedre_.org/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cef-_france_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/conservator_iosa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cse_occupational_hygiene._co._za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cura_con_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/custom_gpt._ai/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/delta_-t._co._uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/denis_on_consulting_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/des_fran_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/disney_land_paris_transfer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dive_2_gether_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dn_ck_.gr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/doc_freak_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dreamfly_.com_.hk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/el_more_indian_art_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exmo_ort_rim._co._uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exo-_hotel-_heidelberg_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/filmora_.wonder_share_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/for-a_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/glossy_glamour_glam_hair_extension_salon_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gozo_ypaz._mx/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gsgl_itzy_galleria_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gulf_news_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/heat_switch_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/helpy_robotics_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/holly_wood_lace_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hotel_hosta_lillo_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hyper_scalers_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ime_rit_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ip_sorex_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ir_muk_.co_.uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/issue_wire_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/jean_cariel_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/klapp_erzae_hnchen_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/koleo_.co.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laser_data_.at/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laurao_xossi_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/layer_.it/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lor_enz_.cc/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lot._dhl._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lp_site._grupo_voalle_.com.br/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mac-_solutions_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mail_chi_.mp/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/many_chat_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/math_.he_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/maxupy_ourads_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mind_theory_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mise_reor_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/miss_orisu_ites_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/net_tita_kka_.fi/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nirva_name_diaso_lutions_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nj_recovery_coach._co/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nordi_cout_door_.ee/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/north_parkave_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/open_gear_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/optima_.nc/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/papa_sand_beer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/paul_ownia_france_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/peak_provi_sions_grocer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/pro_ject_-n_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ptw_dos_imetry_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/r-_tec_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/rca_theme_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/recoverit_.wonder_share_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/reuni_loc._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/richard_-_burdett_.pixels_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sagi_capri_produtora_.com_.br/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sailing_-tech_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/salam_store_-ksa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/scd_key_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/selt._language_cert_.org/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/silicon_expert_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stah_lbau-_menke_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stein_muller_africa._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stel_late_.co/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/steri_line_.it/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tech_target_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/test_.be/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tfi_.co_.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/theer_asure_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/thorn_hill_safari_lodge_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/vacu_umver_damper_.nl/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/valve_.va_login_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/varme_bar_onen_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/wein_location_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/welcome_estes_park_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xen_arc_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xga_mess_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/yach_tingmy_konos_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/youtube_.com/pg.txt"
                    ];

                    getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response3) {
                        fillFormWithRandomResponses(response3, 'textarea#proof_3.form-control.alert-on-type-task');
                    });
                });
            });
        } else {
            console.error('Indice non trouvé.');
        }
    }

    // Rechercher chaque indice dans la liste
    for (const index of searchIndices) {
        searchForIndex(index);
    }

})();


(function() {
    'use strict';

    // Function to get random responses from a source URL
    function getRandomResponses(url, count, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function(response) {
                const responses = response.responseText.split("\n");
                const randomResponses = [];
                for (let i = 0; i < count; i++) {
                    const randomIndex = Math.floor(Math.random() * responses.length);
                    const randomResponse = responses[randomIndex].trim();
                    randomResponses.push(randomResponse);
                }
                callback(randomResponses);
            }
        });
    }

    // Load confirmation message from an external URL
    function loadConfirmationMessage(callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/msg.txt", // Remplacer par le lien du message de confirmation
            onload: function(response) {
                const message = response.responseText.trim();
                callback(message);
            }
        });
    }

    // Load response for vproof from an external URL
    function loadVproofResponse(callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: "https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/cod.txt", // Remplacer par le lien de la réponse pour vproof
            onload: function(response) {
                const vproofResponse = response.responseText.trim();
                callback(vproofResponse);
            }
        });
    }

    // Search for the text "   " on the page
    const foundIndex = document.body.textContent.includes("https://rebrand.ly/6y846o1");//

    if (foundIndex) {
        // Display a confirmation popup before filling the form
        loadConfirmationMessage(function(message) {
            const shouldFillForm = confirm(message);
            if (shouldFillForm) {
                // Fill the form with random responses
                getRandomResponses("https://raw.githubusercontent.com/MieJM98/A-S-A/main/REGI/makl_umat_kerja.com+eng/link.txt", 1, function(response1) {
                    fillFormWithRandomResponses(response1, 'textarea#proof_1.form-control.alert-on-type-task');
                });

                // Load response for vproof
                loadVproofResponse(function(vproofResponse) {
                    fillFormWithRandomResponses([vproofResponse], 'textarea#vproof');
                });

                // Load random responses for proof2
                const sources = [
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/1.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/2.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/3.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/4.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/5.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/6.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/7.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/8.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/9.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/10.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/11.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/12.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/13.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/AD/14.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/360_global_transportation_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/4_seasons_equip_.ca/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/Abile_nefoode_xpress_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/acti_vecam_paign_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ait_ecsa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/alli_anz-_assis_tance_.ie/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ama_zon_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/aquag_lobal_.co_.uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/arrow_head_manor_hotel_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/atti_cuse_xcha_nge_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/badis_cher_-landes_verein_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/beforward_.jp/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/biblical_counse_lingin_sights_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bid._wis_consin_sur_plus._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bio_legio_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/blue-_hori_zon_.gr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bria_nai_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bro_dovi_.hr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/bs_power_.co_.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm-_europe_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/btm_industrial_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/buffet_lour_enco_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/burst_of_class_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/business_.google_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/can_com_.at/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cedre_.org/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cef-_france_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/conservator_iosa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cse_occupational_hygiene._co._za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/cura_con_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/custom_gpt._ai/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/delta_-t._co._uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/denis_on_consulting_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/des_fran_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/disney_land_paris_transfer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dive_2_gether_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dn_ck_.gr/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/doc_freak_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/dreamfly_.com_.hk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/el_more_indian_art_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exmo_ort_rim._co._uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/exo-_hotel-_heidelberg_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/filmora_.wonder_share_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/for-a_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/glossy_glamour_glam_hair_extension_salon_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gozo_ypaz._mx/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gsgl_itzy_galleria_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/gulf_news_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/heat_switch_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/helpy_robotics_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/holly_wood_lace_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hotel_hosta_lillo_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/hyper_scalers_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ime_rit_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ip_sorex_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ir_muk_.co_.uk/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/issue_wire_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/jean_cariel_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/klapp_erzae_hnchen_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/koleo_.co.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laser_data_.at/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/laurao_xossi_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/layer_.it/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lor_enz_.cc/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lot._dhl._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/lp_site._grupo_voalle_.com.br/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mac-_solutions_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mail_chi_.mp/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/many_chat_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/math_.he_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/maxupy_ourads_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mind_theory_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/mise_reor_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/miss_orisu_ites_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/net_tita_kka_.fi/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nirva_name_diaso_lutions_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nj_recovery_coach._co/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/nordi_cout_door_.ee/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/north_parkave_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/open_gear_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/optima_.nc/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/papa_sand_beer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/paul_ownia_france_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/peak_provi_sions_grocer_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/pro_ject_-n_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/ptw_dos_imetry_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/r-_tec_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/rca_theme_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/recoverit_.wonder_share_.net/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/reuni_loc._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/richard_-_burdett_.pixels_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sagi_capri_produtora_.com_.br/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/sailing_-tech_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/salam_store_-ksa_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/scd_key_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/selt._language_cert_.org/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/silicon_expert_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stah_lbau-_menke_.de/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stein_muller_africa._com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/stel_late_.co/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/steri_line_.it/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tech_target_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/test_.be/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/tfi_.co_.za/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/theer_asure_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/thorn_hill_safari_lodge_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/vacu_umver_damper_.nl/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/valve_.va_login_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/varme_bar_onen_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/wein_location_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/welcome_estes_park_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xen_arc_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/xga_mess_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/yach_tingmy_konos_.com/pg.txt",
                    "https://raw.githubusercontent.com/MieJM98/A-S-A/main/2.0.2.4/AD.v2/youtube_.com/pg.txt"
                ];
                getRandomResponses(sources[Math.floor(Math.random() * sources.length)], 2, function(response2) {
                    fillFormWithRandomResponses(response2, 'textarea#proof_2.form-control.alert-on-type-task');
                });
            } else {
                console.log('User chose not to fill the form.');
            }
        });
    } else {
        console.error('Indice non trouvé.');
    }

    // Function to fill the form with random responses
    function fillFormWithRandomResponses(responses, textareaId) {
        const textarea = document.querySelector(textareaId);
        if (textarea) {
            textarea.value = responses.join('\n');
        }
    }

})();